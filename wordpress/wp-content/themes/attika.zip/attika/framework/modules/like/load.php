<?php

include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/like/like.php';
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/like/like-functions.php';