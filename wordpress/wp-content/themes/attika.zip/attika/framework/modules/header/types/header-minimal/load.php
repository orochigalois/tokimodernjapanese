<?php

include_once MIKADO_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-minimal/functions.php';
include_once MIKADO_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-minimal/header-minimal.php';