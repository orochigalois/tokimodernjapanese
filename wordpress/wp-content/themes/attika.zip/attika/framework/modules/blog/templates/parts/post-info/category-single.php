<div class="mkdf-post-info-category">
    <span class="mkdf-post-info-category-text">
        <?php esc_html_e('Category:', 'attika'); ?>
    </span>
    <?php the_category(', '); ?>
</div>