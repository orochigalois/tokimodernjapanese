<?php

include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/sidearea/widgets/sidearea-opener/functions.php';
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/sidearea/widgets/sidearea-opener/side-area-opener.php';