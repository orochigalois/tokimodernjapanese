<div class="mkdf-content-bottom" <?php attika_mikado_inline_style( $content_bottom_style ); ?>>
	<div class="mkdf-content-bottom-inner <?php echo esc_attr( $grid_class ); ?>">
		<?php dynamic_sidebar( $content_bottom_area_sidebar ); ?>
	</div>
</div>