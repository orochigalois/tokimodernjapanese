<?php

include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/recent-posts/functions.php';
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/recent-posts/recent-posts.php';
