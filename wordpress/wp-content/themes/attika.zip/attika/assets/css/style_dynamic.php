<?php

do_action('attika_mikado_action_style_dynamic');