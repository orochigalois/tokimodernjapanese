<?php

include_once ATTIKA_RESTAURANT_SHORTCODES_PATH . '/menu-popup/menu-popup.php';
include_once ATTIKA_RESTAURANT_SHORTCODES_PATH . '/menu-popup/functions.php';