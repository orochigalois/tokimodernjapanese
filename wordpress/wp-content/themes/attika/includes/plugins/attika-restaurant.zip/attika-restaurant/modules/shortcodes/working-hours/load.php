<?php

include_once ATTIKA_RESTAURANT_SHORTCODES_PATH.'/working-hours/functions.php';
include_once ATTIKA_RESTAURANT_SHORTCODES_PATH.'/working-hours/working-hours.php';