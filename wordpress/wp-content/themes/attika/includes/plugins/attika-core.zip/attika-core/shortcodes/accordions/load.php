<?php

include_once ATTIKA_CORE_SHORTCODES_PATH . '/accordions/functions.php';
include_once ATTIKA_CORE_SHORTCODES_PATH . '/accordions/accordion.php';
include_once ATTIKA_CORE_SHORTCODES_PATH . '/accordions/accordion-tab.php';