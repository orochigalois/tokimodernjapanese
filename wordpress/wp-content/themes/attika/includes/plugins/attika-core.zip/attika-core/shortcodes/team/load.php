<?php

include_once ATTIKA_CORE_SHORTCODES_PATH . '/team/functions.php';
include_once ATTIKA_CORE_SHORTCODES_PATH . '/team/team.php';