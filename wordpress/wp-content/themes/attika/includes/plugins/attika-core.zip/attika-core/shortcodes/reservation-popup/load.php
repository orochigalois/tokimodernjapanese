<?php

include_once ATTIKA_CORE_SHORTCODES_PATH . '/reservation-popup/reservation-popup.php';
include_once ATTIKA_CORE_SHORTCODES_PATH . '/reservation-popup/functions.php';
include_once ATTIKA_CORE_SHORTCODES_PATH . '/reservation-popup/template-hooks.php';