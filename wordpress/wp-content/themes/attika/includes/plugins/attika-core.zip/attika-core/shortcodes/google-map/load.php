<?php

include_once ATTIKA_CORE_SHORTCODES_PATH . '/google-map/functions.php';
include_once ATTIKA_CORE_SHORTCODES_PATH . '/google-map/google-map.php';