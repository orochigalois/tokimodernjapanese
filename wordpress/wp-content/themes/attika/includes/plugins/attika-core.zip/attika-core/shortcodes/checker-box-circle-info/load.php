<?php

include_once ATTIKA_CORE_SHORTCODES_PATH . '/checker-box-circle-info/functions.php';
include_once ATTIKA_CORE_SHORTCODES_PATH . '/checker-box-circle-info/checker-box-circle-info.php';