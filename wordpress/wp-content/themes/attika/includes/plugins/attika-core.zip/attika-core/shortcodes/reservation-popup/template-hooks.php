<?php

//Get popup HTML
add_action('attika_mikado_action_before_page_header', 'attika_core_get_reservation_popup');