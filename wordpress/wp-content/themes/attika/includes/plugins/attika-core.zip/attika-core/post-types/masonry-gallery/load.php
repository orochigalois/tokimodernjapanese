<?php

include_once ATTIKA_CORE_CPT_PATH . '/masonry-gallery/masonry-gallery-register.php';
include_once ATTIKA_CORE_CPT_PATH . '/masonry-gallery/helper-functions.php';