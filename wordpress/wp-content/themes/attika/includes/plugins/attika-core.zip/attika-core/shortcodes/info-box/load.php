<?php

include_once ATTIKA_CORE_SHORTCODES_PATH . '/info-box/functions.php';
include_once ATTIKA_CORE_SHORTCODES_PATH . '/info-box/info-box.php';